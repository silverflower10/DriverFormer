#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pretrain_loop.py — Pan-cancer pretraining loop (multi-organ)

Updated on Mon Jul  7 19:20:00 2025
- manifest에서 organ_id를 읽어 고정 매핑 사용(없으면 등장 순서 기반)
- ConditionalNHPPHead(mode="per_head", tie_ln=True)로 조직별 독립 헤드 학습
- Hierarchical Alpha Fusion(FeatClsFusionCtx) 적용 + α warmup 규제 + 로그 출력
- forward의 모든 lam 계산에 tissue_ids=organ_id 전달
- best ckpt에 organ_map 저장
- [NEW] 훈련/평가에서 조직별 로스 리포트(per-organ loss) 추가
- [NEW] 공용 CLS 뱅크(--common-cls) + 라이트 세그(--segs-lite) + FP16 CLS 뱅크(--cls-fp16)
- [NEW] LR 스케줄러 안전 폴백(lr_sched_* 미지정 시 자동 설정)
- [FIX] calibrate_* 내부 잘못된 참조(model_components → model_c)
"""

# --------------------------------------------------------------------------- #
# Imports & setup                                                             #
# --------------------------------------------------------------------------- #
import os, sys, math, random, pickle, argparse, gc, itertools, warnings, json
from functools import partial
from collections import defaultdict, Counter
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, WeightedRandomSampler
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from tqdm import tqdm

# ---- project modules ------------------------------------------------------- #
from ..models.embedders import FeatureEmbedder, ChromosomeEmbedder
from ..models.embedders import HierAlphaFusion as FeatClsFusionCtx   # ★ 계층형 α
from ..models.transformer import GlobalTransformerEncoder
from ..models.nhpp_head import ConditionalNHPPHead, CondCfg

# 세그/콜레이트 (classic + lite 모두 임포트)
from ..data.segments import (
    SegmentDataset,
    segment_cls_embeddings_fixed_lengths,
    segment_collate_fn,
    segment_indices_fixed_lengths,
    segment_collate_fn_lite,
)

from ..data.labels import (
    _bins_from_cls_list,
    _load_mutations_events,
    _build_y_map_from_mutations,
    _attach_labels_from_y_map,
)
import driverformer.data.rolling as R
from ..utils.io import (
    build_chrom_id_map, unwrap, efficient_load_ckpt, efficient_save_ckpt,
    check_pretrained_model_exists, set_seed
)
from ..losses.nhpp import trapezoid_nhpp_loss_segment_weighted
from ..train.attention import save_last_layer_attention, dump_full_attention
from ..utils.stats import compute_mad, compute_iqr, huber_weight
from ..utils.chrom import CHROM_LIST_24

# ===== Globals =============================================================== #
os.environ["TOKENIZERS_PARALLELISM"] = "false"
torch.autograd.set_detect_anomaly(True)

DEBUG_NAN = True
_EPS       = 1e-8
_RATE_MIN  = 1e-9
_RATE_MAX  = 1e6
STRICT_BACKWARD = os.environ.get("DF_STRICT_BACKWARD", "0") == "1"

# ===== A) GPU backend 안전 모드 ============================================ #
import torch.backends.cudnn as _cudnn
_cudnn.enabled = False
_cudnn.benchmark = False
_cudnn.deterministic = True

# sdpa 경고 억제(신 API→구 API 폴백)
try:
    from torch.nn.attention import sdpa_kernel as _sdpa_kernel_new
    _sdpa_kernel_new(enable_flash=False, enable_mem_efficient=False, enable_math=True)
except Exception:
    try:
        from torch.backends.cuda import sdp_kernel as _sdpa_kernel_old
        _sdpa_kernel_old(enable_flash=False, enable_mem_efficient=False, enable_math=True)
    except Exception:
        pass

os.environ.setdefault("CUDA_LAUNCH_BLOCKING", "1")
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")

# ===== NaN/Inf safety helpers =============================================== #
def _nan_to_num_(t: torch.Tensor) -> torch.Tensor:
    return torch.nan_to_num(t, nan=0.0, posinf=_RATE_MAX, neginf=0.0)

def _safe_rate_(lam: torch.Tensor) -> torch.Tensor:
    return _nan_to_num_(lam).clamp(_RATE_MIN, _RATE_MAX)

def _safe_len_(dt: torch.Tensor) -> torch.Tensor:
    return _nan_to_num_(dt).clamp(min=0.0)

def _safe_count_(y: torch.Tensor) -> torch.Tensor:
    return _nan_to_num_(y).clamp(min=0.0)

def _stat(t: torch.Tensor):
    t = _nan_to_num_(t.detach())
    return dict(
        shape=list(t.shape),
        min=float(t.min()),
        max=float(t.max()),
        mean=float(t.mean()),
        n_nan=int((~torch.isfinite(t)).sum().item()),
        n_le0=int((t <= 0).sum().item()),
    )

def _dump_batch_stats(tag: str, lam: torch.Tensor, y: torch.Tensor, dt: torch.Tensor):
    lam = _safe_rate_(lam); y = _safe_count_(y); dt = _safe_len_(dt)
    mu  = lam * dt
    info = {
        "tag": tag,
        "lam": _stat(lam),
        "y":   _stat(y),
        "dt":  _stat(dt),
        "mu":  _stat(mu),
        "y_on_pad": int(((dt <= 0) & (y > 0)).sum().item()),
        "lam_le0":  int((lam <= 0).sum().item()),
    }
    print(f"[DBG] {info}", flush=True)

def _attach_grad_sanitizer(t: torch.Tensor) -> torch.Tensor:
    if t.requires_grad:
        t.register_hook(lambda g: torch.nan_to_num(g, nan=0.0, posinf=0.0, neginf=0.0))
    return t

# --------------------- per-seg NLL helper ---------------------------------- #
def _perseg_nll30k(lam: torch.Tensor, y: torch.Tensor, len_kb: torch.Tensor) -> torch.Tensor:
    lam_safe = lam.clamp(1e-9, 1e6)
    sum_log  = (y * torch.log(lam_safe)).sum(dim=1)
    integ    = (lam_safe * len_kb).sum(dim=1)
    neg_ll   = -(sum_log - integ)
    seg_len  = (len_kb.sum(dim=1) + 1e-9)
    return (neg_ll / seg_len) * 30.0

# --------------------------------------------------------------------------- #
# Manifest loader                                                             #
# --------------------------------------------------------------------------- #
def _load_manifest(path: str) -> List[Dict[str, Any]]:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(path)
    if p.suffix.lower() == ".json":
        data = json.loads(p.read_text())
        if not isinstance(data, list):
            raise ValueError("manifest JSON must be a list of entries")
        rows = data
    else:
        try:
            df = pd.read_csv(p, dtype=str)
        except Exception:
            df = pd.read_csv(p, sep="\t", dtype=str)
        df = df.rename(columns={c: c.strip() for c in df.columns})
        need = {"organ","cls_file","feat_file"}
        if not need.issubset(set(df.columns)):
            raise ValueError(f"manifest must contain columns {sorted(need)}")
        rows = df.fillna("").to_dict("records")

    normed = []
    for r in rows:
        organ = str(r["organ"]).strip()
        cls_f = str(r["cls_file"]).strip()
        fea_f = str(r["feat_file"]).strip()
        mut_f = str(r.get("mutations_file","")).strip() or None
        oid   = r.get("organ_id", None)
        if oid is not None and str(oid).strip() != "":
            oid = int(str(oid).strip())
            if oid < 0: raise ValueError(f"organ_id must be >=0: {oid}")
        else:
            oid = None
        if not (organ and cls_f and fea_f):
            continue
        normed.append(dict(organ=organ, cls_file=cls_f, feat_file=fea_f,
                           mutations_file=mut_f, organ_id=oid))
    if not normed:
        raise ValueError("manifest is empty after normalization")
    return normed

def _build_organ_id_map_from_manifest(entries: List[Dict[str,Any]]) -> Dict[str,int]:
    given = {e["organ"]: e["organ_id"] for e in entries if e.get("organ_id") is not None}
    if given:
        if len(set(given.values())) != len(given.values()):
            raise ValueError("organ_id duplicates found")
        return given
    m = {}
    for e in entries:
        o = e["organ"]
        if o not in m: m[o] = len(m)
    return m

# ------------------------- CLS Bank (lite mode) ---------------------------- #
def _load_common_cls_bank(path: str, fp16: bool = False) -> Dict[Tuple[str,int], np.ndarray]:
    print(f"[CLS] Loading common CLS bank: {path}", flush=True)
    with open(path, "rb") as f:
        cls_list = pickle.load(f)  # [(chrom, w_idx, sbp, ebp, cls_vec, y), ...]
    dtype = np.float16 if fp16 else np.float32
    bank: Dict[Tuple[str,int], np.ndarray] = {}
    for chrom, widx, _sbp, _ebp, vec, _y in cls_list:
        arr = np.asarray(vec, dtype=np.float32).astype(dtype, copy=False)
        bank[(str(chrom), int(widx))] = arr
    d = next(iter(bank.values())).shape[-1] if bank else None
    print(f"[CLS] entries={len(bank):,} dim={d} dtype={dtype}", flush=True)
    return bank

# ===== Calibration (Huber-like) with organ embed ============================ #
@torch.no_grad()
def calibrate_log_c_huber_like_training(model_c, loader, device,
                                        huber_factor: float = 3.0,
                                        use_mad: bool = False,
                                        label_roll: bool = False,
                                        roll_width: int = 1):
    for m in model_c.values(): m.eval()
    nh = unwrap(model_c["nhpp_head"])
    c_cur = float(torch.exp(nh.log_c.detach()).cpu())

    seg_residual = {}
    for b in loader:
        cls_b  = b["cls_array"].to(device)
        feat_b = b["feat_array"].to(device)
        y_b    = _safe_count_(b["y_array"].to(device))
        len_b  = _safe_len_(b["length_array"].to(device))
        cid_b  = b["chrom_id"].to(device)
        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]],
                              device=device, dtype=torch.long)
        key_pad = (len_b <= 0)

        feat_emb = model_c["feature_embedder"](feat_b)
        fused, _ = model_c["feat_cls_fusion"](
            cls_b=cls_b, feat_emb=feat_b, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None
        )
        chr_emb  = model_c["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
        org_emb  = model_c["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
        out      = model_c["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
        lam      = _safe_rate_(model_c["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

        if label_roll and roll_width > 1:
            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=roll_width)
            lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

        mu_b = lam * len_b
        y_np, mu_np = y_b.cpu().numpy(), mu_b.cpu().numpy()
        for i, seg in enumerate(b["raw_segments"]):
            L = seg["cls_array"].shape[0]
            seg_residual[seg["global_idx"]] = float((y_np[i, :L] - mu_np[i, :L]).mean())

    rs = np.array(list(seg_residual.values()), dtype=np.float64)
    scale = compute_mad(rs) if use_mad else compute_iqr(rs)
    if not np.isfinite(scale) or scale <= 0: scale = 1.0
    delta = max(huber_factor * scale, 1e-6)

    def _hw(r, d): a = abs(r);  return 1.0 if a <= d else d/(a + _EPS)
    w_seg = {sid: _hw(r, delta) for sid, r in seg_residual.items()}

    num = den = 0.0
    for b in loader:
        cls_b  = b["cls_array"].to(device)
        feat_b = b["feat_array"].to(device)
        y_b    = _safe_count_(b["y_array"].to(device))
        len_b  = _safe_len_(b["length_array"].to(device))
        cid_b  = b["chrom_id"].to(device)
        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]],
                              device=device, dtype=torch.long)
        key_pad = (len_b <= 0)

        feat     = model_c["feature_embedder"](feat_b)
        fused, _ = model_c["feat_cls_fusion"](
            cls_b=cls_b, feat_emb=feat_b, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None
        )
        chr_emb  = model_c["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
        org_emb  = model_c["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
        out      = model_c["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
        lam      = _safe_rate_(model_c["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

        if label_roll and roll_width > 1:
            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=roll_width)
            lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

        base = lam / max(c_cur, _EPS)
        for i, seg in enumerate(b["raw_segments"]):
            L     = seg["cls_array"].shape[0]
            sid   = seg["global_idx"]
            w     = float(w_seg.get(sid, 1.0))
            y_i   = y_b[i, :L]
            dt_i  = len_b[i, :L]
            base_i= base[i, :L]
            num  += w * float(y_i.sum().item())
            den  += w * float((base_i * dt_i).sum().item())

    if not (np.isfinite(num) and np.isfinite(den)) or num <= _EPS or den <= _EPS:
        print(f"[CAL-HUBER-TRAIN] skip (num={num:.3g}, den={den:.3g}) keep c={c_cur:.6g}", flush=True);  return
    c_star = num / den
    nh.log_c.copy_(torch.tensor(math.log(max(c_star, _EPS)), device=nh.log_c.device))
    print(f"[CAL-HUBER-TRAIN] c_prev={c_cur:.6g} → c_new={c_star:.6g}  ratio={c_star/(c_cur+_EPS):.4f}", flush=True)

# --------------------------------------------------------------------------- #
# Pretrain (multi-organ)                                                      #
# --------------------------------------------------------------------------- #
def pretrain_and_predict(args):
    set_seed(args.seed)

    # (옵션) torch 스레드
    if getattr(args, "torch_threads", None):
        try:
            torch.set_num_threads(int(args.torch_threads))
            print(f"[INFO] torch num_threads = {torch.get_num_threads()}", flush=True)
        except Exception as e:
            print(f"[WARN] set_num_threads failed: {e}", flush=True)

    # ------------------------- 데이터 로딩 (multi-organ) ------------------- #
    manifest = _load_manifest(args.manifest)
    print(f"[INFO] manifest entries = {len(manifest)}", flush=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    n_gpu = torch.cuda.device_count()
    print(f"[INFO] device={device}, #GPUs={n_gpu}", flush=True)

    # organ id map
    organ_id_map = _build_organ_id_map_from_manifest(manifest)
    organ_name_map = {v: k for k, v in organ_id_map.items()}

    # 공용 CLS 라이트 모드 분기
    use_lite   = bool(getattr(args, "segs_lite", False))
    cls_bank   = None
    if use_lite:
        if not getattr(args, "common_cls", None):
            raise ValueError("--segs-lite requires --common-cls")
        cls_bank = _load_common_cls_bank(args.common_cls, fp16=bool(getattr(args, "cls_fp16", False)))

    # feature dim consistency + build segments per organ
    feature_dim_ref = None
    per_organ_segments: Dict[str, List[Dict[str,Any]]] = {}
    for entry in manifest:
        organ = entry["organ"]; oid = organ_id_map[organ]
        with open(entry["cls_file"], "rb") as f:
            cls_list = pickle.load(f)
        with open(entry["feat_file"], "rb") as f:
            feature_dict = pickle.load(f)

        any_feat = next(iter(feature_dict.values()))
        feature_dim = any_feat.shape[-1] if any_feat.ndim > 1 else any_feat.shape[0]
        if feature_dim_ref is None: feature_dim_ref = feature_dim
        elif feature_dim_ref != feature_dim:
            raise ValueError(f"[{organ}] feature_dim mismatch: {feature_dim} vs ref {feature_dim_ref}")

        if use_lite:
            segs = segment_indices_fixed_lengths(
                cls_list, feature_dict,
                seg_len_list=tuple(args.segment_lengths),
                discard_leftover=getattr(args, "discard_leftover", False),
                overlap_factor=args.overlap_factor,
            )
        else:
            segs = segment_cls_embeddings_fixed_lengths(
                cls_list, feature_dict,
                seg_len_list=args.segment_lengths,
                discard_leftover=getattr(args, "discard_leftover", False),
                overlap_factor=args.overlap_factor,
            )

        # (옵션) 라벨 붙이기
        if entry.get("mutations_file"):
            print(f"[LABEL:{organ}] building 1kb labels (PASS only): {entry['mutations_file']}", flush=True)
            cls_bins = _bins_from_cls_list(cls_list)
            ev       = _load_mutations_events(entry["mutations_file"], use_midpoint=True, require_pass=True)
            y_map    = _build_y_map_from_mutations(cls_bins, ev)
            _attach_labels_from_y_map(segs, y_map)
            print(f"[LABEL:{organ}] y_map bins = {len(y_map):,}", flush=True)

        # 메타 부여
        for s in segs:
            s["organ"] = organ
            s["organ_id"] = oid

        per_organ_segments[organ] = segs
        print(f"[INFO] organ={organ:<16s} segs={len(segs):,}", flush=True)

    # 전체 세그 합치고 global_idx 재부여
    all_segments = list(itertools.chain.from_iterable(per_organ_segments.values()))
    for gid, seg in enumerate(all_segments):
        seg["global_idx"] = gid
    print(f"[INFO] #all_segments (multi-organ) = {len(all_segments):,}", flush=True)

    # 조직별/염색체별 split
    train_segs, val_segs = [], []
    for organ, segs in per_organ_segments.items():
        c_map = defaultdict(list)
        for seg in segs: c_map[seg["chrom"]].append(seg)
        for _, lst in c_map.items():
            random.shuffle(lst)
            n = len(lst); n_train = int(n * 0.9)
            train_segs.extend(lst[:n_train]);  val_segs.extend(lst[n_train:])

    ds_train = SegmentDataset(train_segs)
    ds_val   = SegmentDataset(val_segs)
    ds_all   = SegmentDataset(all_segments)

    # collate (classic / lite)
    chrom_id_map = build_chrom_id_map(None)
    if use_lite:
        collate_train = partial(segment_collate_fn_lite, chrom_id_map=chrom_id_map, cutmix_p=args.cutmix_p, cls_bank=cls_bank)
        collate_eval  = partial(segment_collate_fn_lite,  chrom_id_map=chrom_id_map, cutmix_p=0.0, cls_bank=cls_bank)
    else:
        collate_train = partial(segment_collate_fn, chrom_id_map=chrom_id_map, cutmix_p=args.cutmix_p)
        collate_eval  = partial(segment_collate_fn, chrom_id_map=chrom_id_map, cutmix_p=0.0)

    pin = (device.type == "cuda")
    train_loader = DataLoader(ds_train, batch_size=args.batch_size, shuffle=True,
                              collate_fn=collate_train, num_workers=args.num_data_workers, pin_memory=pin)
    train_loader_infer = DataLoader(ds_train, batch_size=args.batch_size, shuffle=False,
                                    collate_fn=collate_eval, num_workers=args.num_data_workers, pin_memory=pin)
    val_loader = DataLoader(ds_val, batch_size=args.batch_size, shuffle=False,
                            collate_fn=collate_eval, num_workers=args.num_data_workers, pin_memory=pin)
    all_loader = DataLoader(ds_all, batch_size=args.batch_size, shuffle=False,
                            collate_fn=collate_eval, num_workers=args.num_data_workers, pin_memory=pin)

    # ------------------------- 모델 --------------------------------------- #
    feat_embedder      = FeatureEmbedder(feature_dim_ref, hidden_dim=args.d_model)
    feat_cls_fusion    = FeatClsFusionCtx(
        hidden_dim=args.d_model,
        chrom_n=len(CHROM_LIST_24),
        w_tok=1.0, w_seg=0.5, w_dom=0.25,
        use_stream_dropout=True, stream_dropout_p=0.15,
        use_alpha_warmup=True, alpha_target=0.35, warmup_epochs=3, warmup_lambda=1e-4,
        alpha0_init=0.5,
    )
    chrom_embedder     = ChromosomeEmbedder(len(CHROM_LIST_24), d=args.d_model)
    organ_embedder     = ChromosomeEmbedder(len(organ_id_map),  d=args.d_model)
    global_transformer = GlobalTransformerEncoder(d_model=args.d_model, nhead=args.nhead,
                                                  num_layers=args.num_layers, dim_feedforward=args.dim_feedforward,
                                                  dropout=args.dropout, max_seq_len=args.max_seq_len)
    nhpp_head          = ConditionalNHPPHead(
        hidden_dim=args.d_model,
        cond=CondCfg(mode="per_head", num_tissues=len(organ_id_map), tie_ln=True),
        rate_min=1e-9, rate_max=1e6
    )

    for m in (feat_embedder, feat_cls_fusion, chrom_embedder, organ_embedder, global_transformer, nhpp_head):
        m.to(device)

    model_components = dict(
        feature_embedder=feat_embedder, feat_cls_fusion=feat_cls_fusion,
        chrom_embedder=chrom_embedder, organ_embedder=organ_embedder,
        global_transformer=global_transformer, nhpp_head=nhpp_head
    )

    if n_gpu > 1:
        print(f"[INFO] Using DataParallel on {n_gpu} GPUs", flush=True)
        for k in model_components:
            model_components[k] = nn.DataParallel(model_components[k])

    # ----- Optimizer/Scheduler ----- #
    param_groups = [
        {"params": itertools.chain(
            model_components["feature_embedder"].parameters(),
            model_components["feat_cls_fusion"].parameters(),
            model_components["chrom_embedder"].parameters(),
            model_components["organ_embedder"].parameters(),
            model_components["global_transformer"].parameters(),
        ), "weight_decay": 1e-3, "lr": args.lr},
        {"params": model_components["nhpp_head"].parameters(), "weight_decay": 0.0, "lr": args.lr},
    ]
    optimizer = AdamW(param_groups, betas=(0.9, 0.999), eps=1e-8)

    # 스케줄러 안전 폴백
    steps_per_epoch = max(1, len(train_loader))
    T0      = getattr(args, "lr_sched_T0", None) or steps_per_epoch
    Tmult   = getattr(args, "lr_sched_Tmult", 1)
    eta_min = getattr(args, "lr_sched_eta_min", None) or max(1e-6, args.lr * 0.3)
    scheduler = CosineAnnealingWarmRestarts(optimizer, T_0=T0, T_mult=Tmult, eta_min=eta_min)

    # ----- Checkpoint/out_dir ----- #
    out_dir = Path(args.out_dir); out_dir.mkdir(parents=True, exist_ok=True)
    model_save_path = out_dir / "trained_model.pt"

    start_epoch, train_flag = 0, True
    best_val_loss = float("inf")

    if args.resume_checkpoint and os.path.isfile(args.resume_checkpoint):
        ckpt = efficient_load_ckpt(args.resume_checkpoint)
        for k in model_components: model_components[k].load_state_dict(ckpt[k], strict=False)
        if "optimizer_state" in ckpt: optimizer.load_state_dict(ckpt["optimizer_state"])
        if "sched_state"     in ckpt: scheduler.load_state_dict(ckpt["sched_state"])
        start_epoch   = ckpt.get("epoch", -1) + 1
        best_val_loss = ckpt.get("best_val_loss", float("inf"))
        del ckpt; gc.collect()
        print(f"[INFO] Resumed from {args.resume_checkpoint} (epoch {start_epoch})", flush=True)
    elif check_pretrained_model_exists(model_save_path):
        ckpt = efficient_load_ckpt(model_save_path)
        for k in model_components: model_components[k].load_state_dict(ckpt[k], strict=False)
        del ckpt; train_flag = False
        print("[INFO] Found trained_model.pt → skip training", flush=True)
    else:
        print("[INFO] Training from scratch (pan-cancer pretraining)", flush=True)

    # ----------------------------- Training loop -------------------------- #
    if train_flag:
        FORCE_DEBUG_FIRST_BATCH = True
        seg_weight_dict   = {seg["global_idx"]: 1.0 for seg in all_segments}
        max_grad_norm     = 1.0
        log_interval      = 1000
        best_state_dict   = None
        epochs_no_improve = 0
        step_global       = start_epoch * max(1, len(train_loader))
        tau, use_rw_sampler = 1.0, False
        train_hist, val_hist = [], []

        organ_sizes = Counter([s["organ_id"] for s in ds_train.segments])
        organ_beta = float(getattr(args, "organ_beta", 0.5))
        organ_weight = {oid: (1.0 / max(1, organ_sizes[oid])) ** organ_beta for oid in organ_sizes}

        def weighted_loss_one_batch(batch, return_ctx=False):
            cls_b  = batch["cls_array"].to(device)
            feat_b = batch["feat_array"].to(device)
            y_b    = _safe_count_(batch["y_array"].to(device))
            len_b  = _safe_len_(batch["length_array"].to(device))
            cid_b  = batch["chrom_id"].to(device)
            oid_b  = torch.tensor([seg["organ_id"] for seg in batch["raw_segments"]],
                                  device=device, dtype=torch.long)
            key_pad = (len_b <= 0)

            feat_emb = model_components["feature_embedder"](feat_b)
            fused, alpha_map = model_components["feat_cls_fusion"](
                cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=epoch
            )

            chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
            org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)

            if getattr(args, "save_attention", False):
                out, attn_last = model_components["global_transformer"](
                    fused + chr_emb + org_emb, key_padding_mask=key_pad, return_attn=True
                )
                unwrap(model_components["global_transformer"]).last_attn_cpu = attn_last[0].detach().cpu()
                torch.cuda.empty_cache()
            else:
                out = model_components["global_transformer"](
                    fused + chr_emb + org_emb, key_padding_mask=key_pad
                )

            out = out.contiguous()
            lam = _safe_rate_(model_components["nhpp_head"](out, tissue_ids=oid_b))
            lam = _attach_grad_sanitizer(lam)

            if args.label_roll and args.label_roll_width > 1:
                lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                lam   = _safe_rate_(lam)
                lam   = _attach_grad_sanitizer(lam)
                y_b   = _safe_count_(y_b)
                len_b = _safe_len_(len_b)

            base_w = [seg_weight_dict.get(seg["global_idx"], 1.0) for seg in batch["raw_segments"]]
            obal   = [organ_weight.get(seg["organ_id"], 1.0) for seg in batch["raw_segments"]]
            w_seg  = torch.tensor([b*w for b, w in zip(base_w, obal)], device=device, dtype=torch.float32)

            loss = trapezoid_nhpp_loss_segment_weighted(lam, y_b, len_b, w_seg)
            loss = loss + unwrap(model_components["feat_cls_fusion"]).alpha_regularizer(alpha_map, epoch)

            # per-organ batch nll
            per_seg_vec = _perseg_nll30k(lam, y_b, len_b)
            oids = torch.tensor([seg["organ_id"] for seg in batch["raw_segments"]],
                                device=per_seg_vec.device)
            per_organ_batch = {}
            for oid in torch.unique(oids).tolist():
                m = per_seg_vec[oids == oid].mean().item()
                per_organ_batch[int(oid)] = float(m)

            if return_ctx:
                return loss, lam.detach(), y_b.detach(), len_b.detach(), alpha_map.detach(), per_organ_batch
            return loss

        for epoch in range(start_epoch, args.epochs):
            for m in model_components.values(): m.train()
            sum_loss, cnt = 0.0, 0

            for _step, batch in enumerate(train_loader):
                step_global += 1
                if DEBUG_NAN:
                    loss_val, lam_dbg, y_dbg, dt_dbg, alpha_dbg, per_organ_stats = weighted_loss_one_batch(batch, True)
                else:
                    loss_val = weighted_loss_one_batch(batch)

                if DEBUG_NAN and FORCE_DEBUG_FIRST_BATCH and step_global == 1:
                    _dump_batch_stats("pre-loss(first-batch)", lam_dbg, y_dbg, dt_dbg)

                if not torch.isfinite(loss_val):
                    if DEBUG_NAN and 'lam_dbg' in locals():
                        _dump_batch_stats("NaN-before-raise", lam_dbg, y_dbg, dt_dbg)
                        lam_s  = torch.clamp(lam_dbg, min=_RATE_MIN, max=_RATE_MAX)
                        y_s    = _safe_count_(y_dbg)
                        dt_s   = _safe_len_(dt_dbg)
                        print(f"[DBG] quick-NLL: Σ(y*logλ)={(y_s*torch.log(lam_s)).sum().item():.4e}  ∫λΔt={(lam_s*dt_s).sum().item():.4e}", flush=True)
                    print(f"[NaN] epoch={epoch} step={step_global}", flush=True)
                    raise RuntimeError("NaN detected")

                optimizer.zero_grad()
                if STRICT_BACKWARD: loss_val.backward()
                else:
                    with torch.autograd.set_detect_anomaly(False): loss_val.backward()

                _bad = 0
                for m in model_components.values():
                    for p in unwrap(m).parameters():
                        if p.grad is not None and not torch.isfinite(p.grad).all():
                            p.grad.data = torch.nan_to_num(p.grad.data, nan=0.0, posinf=0.0, neginf=0.0); _bad += 1
                if _bad: print(f"[GRAD] sanitized {_bad} grads", flush=True)

                for g in optimizer.param_groups:
                    nn.utils.clip_grad_norm_(g["params"], max_grad_norm)

                optimizer.step(); scheduler.step()

                sum_loss += float(loss_val.item()); cnt += 1
                if step_global % log_interval == 0:
                    avg = sum_loss / max(cnt, 1); sum_loss = 0.0; cnt = 0
                    # fusion alpha 로그
                    if 'alpha_dbg' in locals():
                        len_kb = _safe_len_(batch["length_array"].to(device))
                        mask   = (len_kb > 0)
                        alpha_now = float(torch.nan_to_num(alpha_dbg[mask.unsqueeze(-1)], nan=0.5).mean().detach().cpu())
                    else:
                        alpha_now = float('nan')
                    po_named = {organ_name_map.get(k, k): round(v, 3) for k, v in per_organ_stats.items()}
                    print(f"[Epoch {epoch} | Step {step_global}] loss={avg:.4f}  fusion_alpha={alpha_now:.3f}  per_organ_loss={po_named}", flush=True)

            # -------------------- epoch 평가 ------------------------------ #
            def eval_loader(loader):
                for m in model_components.values(): m.eval()
                res = {}
                with torch.no_grad():
                    for b in loader:
                        cls_b  = b["cls_array"].to(device)
                        feat_b = b["feat_array"].to(device)
                        y_b    = _safe_count_(b["y_array"].to(device))
                        len_b  = _safe_len_(b["length_array"].to(device))
                        cid_b  = b["chrom_id"].to(device)
                        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]], device=device, dtype=torch.long)
                        key_pad = (len_b <= 0)

                        feat_emb = model_components["feature_embedder"](feat_b)
                        fused, _ = model_components["feat_cls_fusion"](
                            cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None
                        )
                        chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                        org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                        out = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                        lam = _safe_rate_(model_components["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

                        if args.label_roll and args.label_roll_width > 1:
                            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                            lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

                        mu = lam * len_b
                        y_np, mu_np = y_b.cpu().numpy(), mu.cpu().numpy()
                        for i, seg in enumerate(b["raw_segments"]):
                            L = seg["cls_array"].shape[0]
                            res[seg["global_idx"]] = float((y_np[i, :L] - mu_np[i, :L]).mean())

                rs = np.array(list(res.values()), dtype=np.float64)
                scale = compute_mad(rs) if args.use_mad else compute_iqr(rs)
                if not np.isfinite(scale) or scale <= 0: scale = 1.0
                delta = max(args.huber_factor * scale, 1e-6)
                w_dict = {sid: huber_weight(r, delta) for sid, r in res.items()}

                tot_num = tot_den = 0.0
                with torch.no_grad():
                    for b in loader:
                        cls_b  = b["cls_array"].to(device)
                        feat_b = b["feat_array"].to(device)
                        y_b    = _safe_count_(b["y_array"].to(device))
                        len_b  = _safe_len_(b["length_array"].to(device))
                        cid_b  = b["chrom_id"].to(device)
                        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]], device=device, dtype=torch.long)
                        key_pad = (len_b <= 0)

                        feat_emb = model_components["feature_embedder"](feat_b)
                        fused, _ = model_components["feat_cls_fusion"](
                            cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None
                        )
                        chr_emb = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                        org_emb = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                        out = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                        lam = _safe_rate_(model_components["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

                        if args.label_roll and args.label_roll_width > 1:
                            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                            lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

                        sum_log = (y_b * torch.log(lam)).sum(dim=1)
                        integ   = (lam * len_b).sum(dim=1)
                        neg_ll  = -(sum_log - integ)
                        seg_len = (len_b.sum(dim=1) + _EPS)
                        per_seg = (neg_ll / seg_len) * 30.0

                        ids = [seg["global_idx"] for seg in b["raw_segments"]]
                        w   = torch.tensor([w_dict.get(i, 1.0) for i in ids], device=per_seg.device, dtype=per_seg.dtype)
                        tot_num += float((w * per_seg).sum().item());  tot_den += float(w.sum().item())
                return tot_num / max(tot_den, _EPS)

            # per-organ 평가 리포트
            def evaluate_per_organ(loader):
                for m in model_components.values(): m.eval()
                organ_sums = {}
                with torch.no_grad():
                    for b in loader:
                        cls_b  = b["cls_array"].to(device)
                        feat_b = b["feat_array"].to(device)
                        y_b    = _safe_count_(b["y_array"].to(device))
                        len_b  = _safe_len_(b["length_array"].to(device))
                        cid_b  = b["chrom_id"].to(device)
                        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]],
                                              device=device, dtype=torch.long)
                        key_pad  = (len_b <= 0)

                        feat_emb = model_components["feature_embedder"](feat_b)
                        fused, _ = model_components["feat_cls_fusion"](
                            cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None
                        )
                        chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                        org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                        out      = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                        lam      = _safe_rate_(model_components["nhpp_head"](out.contiguous(), tissue_ids=oid_b))
                        if args.label_roll and args.label_roll_width > 1:
                            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)

                        per_seg_vec = _perseg_nll30k(lam, y_b, len_b)
                        for i, seg in enumerate(b["raw_segments"]):
                            oid = seg["organ_id"]
                            s, c = organ_sums.get(oid, (0.0, 0))
                            organ_sums[oid] = (s + float(per_seg_vec[i].item()), c + 1)
                return {oid: (s / max(c, 1)) for oid, (s, c) in organ_sums.items()}

            calibrate_log_c_huber_like_training(
                model_components, train_loader_infer, device,
                huber_factor=args.huber_factor, use_mad=args.use_mad,
                label_roll=args.label_roll, roll_width=args.label_roll_width
            )

            train_loss = eval_loader(train_loader_infer)
            val_loss   = eval_loader(val_loader)
            per_org_train = {organ_name_map.get(k, k): round(v, 3) for k, v in evaluate_per_organ(train_loader_infer).items()}
            per_org_val   = {organ_name_map.get(k, k): round(v, 3) for k, v in evaluate_per_organ(val_loader).items()}
            print(f"[Epoch {epoch}] Train={train_loss:.4f}  Val={val_loss:.4f}", flush=True)
            print(f"    Per-organ Train: {per_org_train}", flush=True)
            print(f"    Per-organ   Val: {per_org_val}", flush=True)

            # -------- residual sampler (organ-balanced) -------- #
            def compute_segment_residual():
                for m in model_components.values(): m.eval()
                res = {}
                with torch.no_grad():
                    for b in train_loader_infer:
                        cls_b  = b["cls_array"].to(device)
                        feat_b = b["feat_array"].to(device)
                        y_b    = _safe_count_(b["y_array"].to(device))
                        len_b  = _safe_len_(b["length_array"].to(device))
                        cid_b  = b["chrom_id"].to(device)
                        oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]],
                                              device=device, dtype=torch.long)
                        key_pad = (len_b <= 0)

                        feat = model_components["feature_embedder"](feat_b)
                        fused, _ = model_components["feat_cls_fusion"](cls_b, feat_b, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None)
                        chr_emb = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                        org_emb = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                        out     = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                        lam     = _safe_rate_(model_components["nhpp_head"](out))
                        if args.label_roll and args.label_roll_width > 1:
                            lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                            lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

                        mu = lam * len_b
                        y_np, mu_np = y_b.cpu().numpy(), mu.cpu().numpy()
                        for i, seg in enumerate(b["raw_segments"]):
                            L = seg["cls_array"].shape[0]
                            res[seg["global_idx"]] = float((y_np[i, :L] - mu_np[i, :L]).mean())
                return res

            seg_res = compute_segment_residual()
            rs = np.array(list(seg_res.values()))
            scale = compute_mad(rs) if args.use_mad else compute_iqr(rs)
            if not np.isfinite(scale) or scale <= 0: scale = 1.0
            delta = max(args.huber_factor * scale, 1e-6)
            seg_weight_dict = {sid: huber_weight(r, delta) for sid, r in seg_res.items()}

            def build_sampler(resid_dict, tau, alpha, beta, organ_weight_local):
                abs_r  = np.array([abs(resid_dict.get(seg["global_idx"], 0.0)) for seg in ds_train.segments], np.float64)
                len_kb = np.array([(seg["end_array"].shape[0] and (seg["end_array"][-1] - seg["start_array"][0] + 1) / 1000.0) for seg in ds_train.segments], np.float64)
                org_w  = np.array([organ_weight_local.get(seg["organ_id"], 1.0) for seg in ds_train.segments], np.float64)
                p = np.exp(-beta * abs_r / (tau + _EPS)) * np.maximum(len_kb, _EPS) ** alpha * org_w
                s = float(np.nansum(p))
                if (not np.isfinite(p).all()) or s <= 0.0:
                    p = np.full_like(p, 1.0 / len(p))
                else:
                    p /= s
                return WeightedRandomSampler(torch.DoubleTensor(p), len(ds_train), replacement=True)

            if epoch == 3 and not use_rw_sampler:
                use_rw_sampler = True
                train_loader = DataLoader(
                    ds_train, batch_size=args.batch_size,
                    sampler=build_sampler(seg_res, tau, args.len_alpha, args.res_beta, organ_weight),
                    collate_fn=collate_train, num_workers=args.num_data_workers, pin_memory=pin
                )
                print(f"[INFO] Residual-weighted + organ-balanced sampler enabled @epoch {epoch}", flush=True)
            elif use_rw_sampler:
                tau *= 0.999
                train_loader = DataLoader(
                    ds_train, batch_size=args.batch_size,
                    sampler=build_sampler(seg_res, tau, args.len_alpha, args.res_beta, organ_weight),
                    collate_fn=collate_train, num_workers=args.num_data_workers, pin_memory=pin
                )

            improved = (val_loss < best_val_loss - best_val_loss * getattr(args, "min_delta_pct", 0.5) / 100.0) if best_val_loss != float("inf") else True
            if improved:
                best_val_loss = val_loss; epochs_no_improve = 0
                best_state_dict = {k: model_components[k].state_dict() for k in model_components}
                ckpt_common = {
                    **best_state_dict, "epoch": epoch,
                    "optimizer_state": optimizer.state_dict(),
                    "sched_state": scheduler.state_dict(),
                    "best_val_loss": best_val_loss,
                    "organ_map": organ_id_map,
                }
                if getattr(args, "save_each_best", False):
                    ep_path = os.path.join(out_dir, f"checkpoint_epoch_{epoch:03d}.pt")
                    efficient_save_ckpt(ep_path, **ckpt_common)
                efficient_save_ckpt(model_save_path, **ckpt_common)
                print(f"[INFO] New best Val={best_val_loss:.4f}", flush=True)
                if getattr(args, "save_attention", False):
                    save_last_layer_attention(unwrap(model_components["global_transformer"]), epoch, step_global, out_dir)
                    torch.cuda.empty_cache()
            else:
                epochs_no_improve += 1

            if getattr(args, "early_stop", False) and epochs_no_improve >= getattr(args, "patience", 5):
                print("[INFO] Early stopping (patience reached)", flush=True)
                break

        # 학습 곡선 저장
        plt.figure()
        x = range(len(train_hist))
        plt.plot(x, train_hist, marker="o", label="train")
        plt.plot(x, val_hist, marker="x", label="val")
        plt.xlabel("Epoch"); plt.ylabel("Loss"); plt.legend()
        plt.savefig(os.path.join(out_dir, "train_val_loss_per_epoch.png")); plt.close()

    # ------------------------------------------------------------------- #
    # Final evaluation & predictions                                      #
    # ------------------------------------------------------------------- #
    print("[INFO] Loading best model for final evaluation ..", flush=True)
    best_ckpt = efficient_load_ckpt(model_save_path)
    for k in model_components:
        model_components[k].load_state_dict(best_ckpt[k], strict=False)
    del best_ckpt; gc.collect(); torch.cuda.empty_cache()

    calibrate_log_c_huber_like_training(
        model_components, all_loader, device,
        huber_factor=args.huber_factor, use_mad=args.use_mad,
        label_roll=args.label_roll, roll_width=args.label_roll_width
    )

    def evaluate(loader):
        for m in model_components.values(): m.eval()
        res = {}
        with torch.no_grad():
            for b in loader:
                cls_b  = b["cls_array"].to(device)
                feat_b = b["feat_array"].to(device)
                y_b    = _safe_count_(b["y_array"].to(device))
                len_b  = _safe_len_(b["length_array"].to(device))
                cid_b  = b["chrom_id"].to(device)
                oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]], device=device, dtype=torch.long)
                key_pad  = (len_b <= 0)

                feat_emb = model_components["feature_embedder"](feat_b)
                fused, _ = model_components["feat_cls_fusion"](cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None)
                chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                out      = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                lam      = _safe_rate_(model_components["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

                if args.label_roll and args.label_roll_width > 1:
                    lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                    lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

                mu_b = lam * len_b
                for i, seg in enumerate(b["raw_segments"]):
                    L = seg["cls_array"].shape[0]
                    res[seg["global_idx"]] = float((y_b[i, :L] - mu_b[i, :L]).mean().item())

        rs     = np.array(list(res.values()), dtype=np.float64)
        scale  = compute_mad(rs) if args.use_mad else compute_iqr(rs)
        delta  = max(args.huber_factor * scale, 1e-9)
        w_dict = {sid: huber_weight(r, delta) for sid, r in res.items()}

        tot_num, tot_den = 0.0, 0.0
        with torch.no_grad():
            for b in loader:
                cls_b  = b["cls_array"].to(device)
                feat_b = b["feat_array"].to(device)
                y_b    = _safe_count_(b["y_array"].to(device))
                len_b  = _safe_len_(b["length_array"].to(device))
                cid_b  = b["chrom_id"].to(device)
                oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]], device=device, dtype=torch.long)
                key_pad  = (len_b <= 0)

                feat_emb = model_components["feature_embedder"](feat_b)
                fused, _ = model_components["feat_cls_fusion"](cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None)
                chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)

                out      = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                out      = out.contiguous()
                lam      = _safe_rate_(model_components["nhpp_head"](out, tissue_ids=oid_b))
                if args.label_roll and args.label_roll_width > 1:
                    lam, y_b, len_b = R.rolling_sum_nhpp(lam, y_b, len_b, width=args.label_roll_width)
                    lam = _safe_rate_(lam); y_b = _safe_count_(y_b); len_b = _safe_len_(len_b)

                sum_log  = (y_b * torch.log(lam)).sum(dim=1)
                integ    = (lam * len_b).sum(dim=1)
                neg_ll   = -(sum_log - integ)
                seg_len  = (len_b.sum(dim=1) + _EPS)
                per_seg  = (neg_ll / seg_len) * 30.0

                ids = [seg["global_idx"] for seg in b["raw_segments"]]
                w   = torch.tensor([w_dict.get(i, 1.0) for i in ids], device=per_seg.device, dtype=per_seg.dtype)
                tot_num += float((w * per_seg).sum().item())
                tot_den += float(w.sum().item())

        return tot_num / max(tot_den, 1e-9)

    print(f"final Train_loss = {evaluate(train_loader_infer):.4f}", flush=True)
    print(f"final Val_loss   = {evaluate(val_loader):.4f}", flush=True)

    @torch.no_grad()
    def predict_and_save(loader, name):
        for m in model_components.values(): m.eval()
        rows = []
        with torch.no_grad():
            for b in loader:
                cls_b  = b["cls_array"].to(device)
                feat_b = b["feat_array"].to(device)
                y_b    = _safe_count_(b["y_array"].to(device))
                len_b  = _safe_len_(b["length_array"].to(device))
                s_bp   = b["start_array"].detach().cpu().numpy()
                e_bp   = b["end_array"].detach().cpu().numpy()
                cid_b  = b["chrom_id"].to(device)
                oid_b  = torch.tensor([seg["organ_id"] for seg in b["raw_segments"]], device=device, dtype=torch.long)
                key_pad  = (len_b <= 0)

                feat_emb = model_components["feature_embedder"](feat_b)
                fused, _ = model_components["feat_cls_fusion"](cls_b, feat_emb, chrom_id=cid_b, valid_mask=(len_b > 0), epoch_idx=None)
                chr_emb  = model_components["chrom_embedder"](cid_b).unsqueeze(1).expand_as(fused)
                org_emb  = model_components["organ_embedder"](oid_b).unsqueeze(1).expand_as(fused)
                out      = model_components["global_transformer"](fused + chr_emb + org_emb, key_padding_mask=key_pad)
                lam_raw  = _safe_rate_(model_components["nhpp_head"](out.contiguous(), tissue_ids=oid_b))

                lam_save = lam_raw
                if args.label_roll and args.label_roll_width > 1:
                    lam_r, _y_ignore, _dt_ignore = R.rolling_sum_nhpp(lam_raw, y_b, len_b, width=args.label_roll_width)
                    lam_save = _safe_rate_(lam_r)

                lam_np  = lam_save.detach().cpu().numpy()
                y_np    = y_b.detach().cpu().numpy()
                len_np  = len_b.detach().cpu().numpy()

                B, T = lam_np.shape
                for i, seg in enumerate(b["raw_segments"]):
                    L = seg["cls_array"].shape[0]
                    L_eff = min(L, T, y_np.shape[1], len_np.shape[1], s_bp.shape[1], e_bp.shape[1])
                    if L_eff <= 0: continue
                    organ = seg["organ"]; chrom = seg["chrom"]
                    for j in range(L_eff):
                        rows.append(dict(
                            organ=organ, chrom=chrom,
                            start=int(s_bp[i, j]), end=int(e_bp[i, j]),
                            lam_pred=float(lam_np[i, j]),
                            obs_count=float(y_np[i, j]),
                        ))

        df = pd.DataFrame(rows).sort_values(["organ","chrom", "start"])
        out_file = out_dir / f"{name}_prediction.csv"
        df.to_csv(out_file, index=False)
        print(f"[INFO] {name} saved → {out_file} (bins={len(df)})", flush=True)

    predict_and_save(train_loader_infer, "train")
    predict_and_save(val_loader,   "val")
    predict_and_save(all_loader,   "all")

    if getattr(args, "save_attention", False):
        dump_full_attention(model_components, all_loader, device, out_dir / "attn" / "final_full_attention.pt")

    print("[DONE] Pan-cancer pretraining complete; predictions & attentions saved.", flush=True)
    return (out_dir / "all_prediction.csv").as_posix()

# ------------------------------ CLI --------------------------------- #
def build_argparser():
    p = argparse.ArgumentParser(description="Pan-cancer pretraining (multi-organ)")
    # 필수
    p.add_argument("--manifest", required=True, type=str,
                   help="JSON/CSV/TSV manifest with fields: organ, cls_file, feat_file[, mutations_file][, organ_id]")
    p.add_argument("--out-dir", required=True, type=str, help="Output directory")

    # 하이퍼파라미터
    p.add_argument("--epochs", type=int, default=2)
    p.add_argument("--batch-size", type=int, default=128)
    p.add_argument("--lr", type=float, default=2e-4)
    p.add_argument("--seed", type=int, default=42)

    p.add_argument("--d-model", type=int, default=768)
    p.add_argument("--nhead", type=int, default=8)
    p.add_argument("--num-layers", type=int, default=6)
    p.add_argument("--dim-feedforward", type=int, default=3072)
    p.add_argument("--dropout", type=float, default=0.2)
    p.add_argument("--max-seq-len", type=int, default=1024)

    p.add_argument("--segment-lengths", nargs="+", type=int, default=[10, 50, 100])
    p.add_argument("--discard-leftover", action="store_true")
    p.add_argument("--overlap-factor", type=float, default=0.3)

    p.add_argument("--num-data-workers", type=int, default=8)
    p.add_argument("--torch-threads", type=int, default=8)

    p.add_argument("--use-mad", action="store_true")
    p.add_argument("--huber-factor", type=float, default=3.0)
    p.add_argument("--cutmix-p", type=float, default=0.2)

    p.add_argument("--label-roll", action="store_true")
    p.add_argument("--label-roll-width", type=int, default=2)

    p.add_argument("--organ-beta", type=float, default=0.5,
                   help="organ-balanced sampler exponent (0: no balance)")

    # LR scheduler knobs (optional)
    p.add_argument("--lr-sched-T0", type=int, default=None,
                   help="CosineAnnealingWarmRestarts T_0 (default: steps_per_epoch)")
    p.add_argument("--lr-sched-Tmult", type=int, default=1,
                   help="CosineAnnealingWarmRestarts T_mult (default: 1)")
    p.add_argument("--lr-sched-eta-min", type=float, default=None,
                   help="CosineAnnealingWarmRestarts eta_min (default: 0.3 * lr)")

    # 메모리 절약(공용 CLS + 라이트 세그)
    p.add_argument("--common-cls", type=str, default=None,
                   help="Path to shared CLS pickle for memory-saving CLS bank")
    p.add_argument("--segs-lite", action="store_true",
                   help="Use lite segments (store widx only; assemble CLS from bank in collate)")
    p.add_argument("--cls-fp16", action="store_true",
                   help="Keep CLS bank as float16 (assembled to float32 on batch)")

    # 기타
    p.add_argument("--save-each-best", action="store_true")
    p.add_argument("--early-stop", action="store_true")
    p.add_argument("--patience", type=int, default=5)
    p.add_argument("--min-delta-pct", type=float, default=0.5)

    # ������ 누락되었던 선택 인자 추가
    p.add_argument("--resume-checkpoint", type=str, default=None,
                   help="Path to checkpoint to resume (optional)")
    p.add_argument("--save-attention", action="store_true",
                   help="Save attention maps during training/evaluation")

    return p



if __name__ == "__main__":
    args = build_argparser().parse_args()
    pretrain_and_predict(args)
