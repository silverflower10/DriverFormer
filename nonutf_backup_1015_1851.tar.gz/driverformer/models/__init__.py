# models/__init__.py

# ���� Embedding & Fusion
from .embedders import FeatureEmbedder, ChromosomeEmbedder
from .embedders import FeatClsFusion           # (��Į�� ��)
from .embedders import HierAlphaFusion as FeatClsFusionCtx  # ����ȣȯ ��Ī

# ���� Transformer
from .transformer import (
    RoPE, SwiGLUFFN, AttnEncoderLayer,
    FoundationEncoder, GlobalTransformerEncoder
)

# ���� NHPP Heads
from .nhpp_head import (
    NHPPHead,                 # shared alias
    ConditionalNHPPHead,      # �Ǳ���
    CondCfg, build_nhpp_head
)

__all__ = [
    # embedders/fusion
    "FeatureEmbedder", "ChromosomeEmbedder",
    "FeatClsFusion", "FeatClsFusionCtx",
    # transformer
    "RoPE", "SwiGLUFFN", "AttnEncoderLayer",
    "FoundationEncoder", "GlobalTransformerEncoder",
    # heads
    "NHPPHead", "ConditionalNHPPHead", "CondCfg", "build_nhpp_head",
]
